package com.example.gesturecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * GestureAccessibilityService: User ko Settings > Accessibility me
 * jaake ye service manually ON karni hogi (Android security requirement,
 * koi bhi app khud se ye permission force nahi le sakta - ye jaan boojhkar
 * banaya gaya hai taaki malicious apps automatic control na le saken).
 *
 * Ek baar ON hone ke baad, ye service kisi bhi jagah tap ya swipe
 * "dispatch" kar sakti hai - jaise koi asli finger touch kar raha ho.
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        // OverlayService se seedha access ke liye simple singleton reference
        var instance: GestureAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("GestureControl", "Accessibility Service connected ✅")
    }

    /** Screen par (x, y) coordinate pe ek tap simulate karta hai */
    fun performTapAt(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)

        val gestureBuilder = GestureDescription.Builder()
        val strokeDesc = GestureDescription.StrokeDescription(path, 0, 100)
        gestureBuilder.addStroke(strokeDesc)

        dispatchGesture(gestureBuilder.build(), null, null)
        Log.d("GestureControl", "Tap dispatch kiya: ($x, $y)")
    }

    /** Ek jagah se doosri jagah swipe simulate karta hai (jaise scroll/next) */
    fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300) {
        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)

        val gestureBuilder = GestureDescription.Builder()
        val strokeDesc = GestureDescription.StrokeDescription(path, 0, durationMs)
        gestureBuilder.addStroke(strokeDesc)

        dispatchGesture(gestureBuilder.build(), null, null)
    }

    /**
     * Naya app kholna (jaise YouTube). Iske liye Accessibility ki zaroorat
     * nahi, normal Intent se ho jaata hai - lekin yahan rakha hai taaki
     * gesture se app-launch bhi trigger kar sako.
     *
     * Common package names:
     * YouTube = com.google.android.youtube
     * WhatsApp = com.whatsapp
     * Instagram = com.instagram.android
     * Chrome = com.android.chrome
     */
    fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Log.e("GestureControl", "App nahi mila: $packageName (installed hai ya nahi check karo)")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Yahan aap dusre app ki screen ka content bhi padh sakte ho
        // (event.source se) agar aage automation banani ho, jaise
        // "jab YouTube khule to automatically pehla video pe tap karo"
    }

    override fun onInterrupt() {
        Log.d("GestureControl", "Accessibility Service interrupt hui")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}

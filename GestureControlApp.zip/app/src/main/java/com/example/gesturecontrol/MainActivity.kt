package com.example.gesturecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * MainActivity: Yahan se user teeno zaroori permissions grant karta hai:
 * 1) Camera permission
 * 2) "Display over other apps" (overlay) permission
 * 3) Accessibility Service enable karna (Settings me manually on karna padta hai,
 *    Android security ki wajah se ye app khud se force nahi kar sakta)
 */
class MainActivity : AppCompatActivity() {

    private val CAMERA_PERMISSION_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val btnCamera = findViewById<Button>(R.id.btnCameraPermission)
        val btnOverlay = findViewById<Button>(R.id.btnOverlayPermission)
        val btnAccessibility = findViewById<Button>(R.id.btnAccessibilitySettings)
        val btnStart = findViewById<Button>(R.id.btnStartService)

        btnCamera.setOnClickListener {
            requestCameraPermission()
        }

        btnOverlay.setOnClickListener {
            requestOverlayPermission()
        }

        btnAccessibility.setOnClickListener {
            // User ko manually apni Accessibility service ON karni hogi
            // Settings > Accessibility > Downloaded apps > Gesture Control
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnStart.setOnClickListener {
            if (checkAllPermissions()) {
                val intent = Intent(this, OverlayService::class.java)
                ContextCompat.startForegroundService(this, intent)
                statusText.text = "Service chalu ho gayi ✅ Ab kisi bhi app me jao, floating cursor dikhega"
            } else {
                statusText.text = "Pehle sabhi 3 permissions do ⚠️"
            }
        }
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE
            )
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun checkAllPermissions(): Boolean {
        val cameraGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        val overlayGranted = Settings.canDrawOverlays(this)
        // Accessibility service check onServiceConnected() se hota hai, yahan simple rakha hai
        return cameraGranted && overlayGranted
    }
}

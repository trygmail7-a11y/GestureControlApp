package com.example.gesturecontrol

import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.framework.image.BitmapImageBuilder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * OverlayService: Ye service background me camera chalati hai, MediaPipe se
 * hand landmarks nikalti hai, aur ek floating cursor view sabhi apps ke upar
 * dikhati hai (jaise Facebook chat-head). Jab "fist" gesture ho, ye
 * GestureAccessibilityService ko bataati hai ki us jagah click/tap kare.
 *
 * NOTE: MediaPipe ke liye 'hand_landmarker.task' model file
 * app/src/main/assets/ folder me daalni hogi. Ye file yahan se milti hai:
 * https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
 */
class OverlayService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarker: HandLandmarker? = null

    companion object {
        const val CHANNEL_ID = "gesture_overlay_channel"
        const val NOTIF_ID = 1
        // Dusre component (Accessibility Service) ke saath cursor position
        // share karne ke liye simple static holder
        var lastCursorX: Float = 0f
        var lastCursorY: Float = 0f
        var isFistClosed: Boolean = false
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        cameraExecutor = Executors.newSingleThreadExecutor()

        setupOverlayView()
        setupHandLandmarker()
        startCamera()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Gesture Control", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gesture Control chalu hai")
            .setContentText("Haath ke ishare se phone control ho raha hai")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
    }

    /** Floating cursor jo har app ke upar dikhega */
    private fun setupOverlayView() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_cursor, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 0

        windowManager.addView(overlayView, params)
    }

    private fun moveCursorTo(x: Float, y: Float) {
        val params = overlayView.layoutParams as WindowManager.LayoutParams
        params.x = x.toInt()
        params.y = y.toInt()
        windowManager.updateViewLayout(overlayView, params)
        lastCursorX = x
        lastCursorY = y
    }

    private fun setupHandLandmarker() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setResultListener(this::onHandResult)
                .setErrorListener { e -> Log.e("GestureControl", "HandLandmarker error: ${e.message}") }
                .build()

            handLandmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            Log.e("GestureControl", "Model load fail: ${e.message}. " +
                    "hand_landmarker.task file assets/ folder me daalo.")
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                processFrame(imageProxy)
            }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, imageAnalysis
                )
            } catch (e: Exception) {
                Log.e("GestureControl", "Camera bind fail: ${e.message}")
            }
        }, ContextCompat_getMainExecutor())
    }

    // Helper: avoids extra import clutter in this skeleton
    private fun ContextCompat_getMainExecutor() =
        androidx.core.content.ContextCompat.getMainExecutor(this)

    private fun processFrame(imageProxy: ImageProxy) {
        try {
            val bitmap = imageProxy.toBitmap() // NOTE: needs conversion util in real project
            val mpImage = BitmapImageBuilder(bitmap).build()
            handLandmarker?.detectAsync(mpImage, System.currentTimeMillis())
        } catch (e: Exception) {
            Log.e("GestureControl", "Frame process error: ${e.message}")
        } finally {
            imageProxy.close()
        }
    }

    private fun onHandResult(result: HandLandmarkerResult, input: com.google.mediapipe.framework.image.MPImage) {
        if (result.landmarks().isEmpty()) return

        val landmarks = result.landmarks()[0]
        // Index finger tip = landmark 8
        val indexTip = landmarks[8]

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        // Mirror X kyunki front camera hai
        val screenX = (1 - indexTip.x()) * screenWidth
        val screenY = indexTip.y() * screenHeight

        moveCursorTo(screenX, screenY)

        // Simple fist detection: agar sab fingertips palm ke paas hain
        val fingerTips = listOf(8, 12, 16, 20)
        val fingerBases = listOf(6, 10, 14, 18)
        val closedCount = fingerTips.indices.count { i ->
            landmarks[fingerTips[i]].y() > landmarks[fingerBases[i]].y()
        }
        val fistNow = closedCount >= 3

        if (fistNow && !isFistClosed) {
            // Naya fist bana -> Accessibility service ko tap karne bolo
            isFistClosed = true
            GestureAccessibilityService.instance?.performTapAt(screenX, screenY)
        } else if (!fistNow) {
            isFistClosed = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::overlayView.isInitialized) windowManager.removeView(overlayView)
        cameraExecutor.shutdown()
        handLandmarker?.close()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}

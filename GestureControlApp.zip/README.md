# Gesture Control App — Setup Guide

Ye ek **starter Android Studio project** hai jo haath ke gestures se
kisi bhi app ko control karne ka base architecture deta hai. Ye HTML
se nahi banega — Android Studio hi chahiye.

## Kya-kya kaam karta hai
- Background me camera chalti hai (foreground service)
- Floating cursor sabhi apps ke upar dikhta hai (overlay permission)
- Fist gesture pe Accessibility Service us jagah **real tap** bhejti hai
- `launchApp()` function se koi bhi app kholi ja sakti hai (Intent se)

## Zaroori Steps (in order)

### 1. Android Studio install karo
https://developer.android.com/studio se latest version download karo

### 2. Ye folder Android Studio me kholo
`File > Open` > `GestureControlApp` folder select karo. Gradle sync
hone dena, isme 2-5 minute lag sakte hain (internet chahiye).

### 3. Hand tracking model file daalo
MediaPipe ka model file khud download karke daalna padega (size ki
wajah se ye is project me include nahi hai):

1. Ye link se download karo:
   `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task`
2. `app/src/main/assets/` naam ka folder banao (agar nahi hai)
3. Downloaded file ko `hand_landmarker.task` naam se us folder me daalo

### 4. Bitmap conversion helper add karo
`ImageProxy.toBitmap()` naya CameraX API hai — agar aapka CameraX
version isko support nahi karta, to `androidx.camera:camera-extensions`
ya YUV-to-Bitmap manual converter add karna padega. Ye starter code me
simplify kiya gaya hai taaki structure samajh aaye.

### 5. Run karo (real phone pe, emulator me camera issues aate hain)
USB se phone connect karo, Developer Options me USB Debugging ON karo,
phir Android Studio me green ▶️ Run button dabao.

### 6. App khulne ke baad 3 permissions do
1. Camera permission
2. "Display over other apps" permission
3. Settings > Accessibility > Downloaded Apps > Gesture Control > ON karo
   (Android ye manually karwata hai — security ke liye, koi app khud
   se ye permission nahi le sakti)

### 7. "Start" button dabao
Ab kisi bhi app me jao (YouTube, WhatsApp, etc.) — floating cursor
dikhega jo haath ke movement se chalega, aur fist banane par wahan
tap ho jayega.

## Important Warnings

- **Accessibility Service ka misuse illegal hai.** Ye permission bahut
  powerful hai (screen padh sakti hai, kisi bhi jagah tap kar sakti
  hai) — isiliye Play Store bahut strict review karta hai aise apps
  ka. Sirf apne personal use / testing ke liye rakho.
- Play Store pe publish karna hai to Google ko explain karna padega ki
  Accessibility Service kyun chahiye (accessibility/automation purpose
  clearly batana hoga), warna app reject ho sakti hai.
- Battery drain zyada hoga kyunki camera + hand tracking background me
  continuously chalti hai.

## Aage kya add kar sakte ho
- `GestureAccessibilityService.launchApp("com.google.android.youtube")`
  jaisa call karke gesture se specific app khol sakte ho
- `performSwipe()` use karke gesture se page/video scroll bhi kar
  sakte ho
- Alag gestures (peace sign, thumbs up) detect karke unko alag actions
  se map kar sakte ho `OverlayService.kt` ke `onHandResult()` function
  me
